import "./App.css";
import { Switch, Route } from "react-router-dom";
import HomePage from "./pages/homepage/homepage";
import HotelPreviewPage from "./pages/hotelPreviewPage/hotelPreviewPage";
import SingleHotelPage from "./pages/singleHotelPage/singleHotelPage";
import Header from "./components/headerComponent/headerComponent";
import Footer from "./components/footerComponent/footerComponent";

function App() {
  return (
    <div>
      <Header />
      <Switch>
        <Route path="/" component={HomePage} exact />
        <Route
          path="/:rid/:ci/:co/:ad/:chi/:in"
          component={HotelPreviewPage}
          exact
        />
        <Route path="/hotel/:id" component={SingleHotelPage} exact />
      </Switch>
      <Footer />
    </div>
  );
}

export default App;
