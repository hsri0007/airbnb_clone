import React from "react";
import HotelPreviewComponent from "../../components/hotelPreviewComponent/hotelPreviewComponent";

const HotelPreviewPage = () => {
  return (
    <div>
      <HotelPreviewComponent />
    </div>
  );
};

export default HotelPreviewPage;
