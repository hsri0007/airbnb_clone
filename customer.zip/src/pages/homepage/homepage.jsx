import React from "react";
import LandingComponent from "../../components/homepageComponents/LandingComponent/LandingComponent";
import ContentComponent from "../../components/homepageComponents/contentComponent/contentComponent";

const HomePage = () => {
  return (
    <div>
      <LandingComponent />
      <ContentComponent />
    </div>
  );
};

export default HomePage;
