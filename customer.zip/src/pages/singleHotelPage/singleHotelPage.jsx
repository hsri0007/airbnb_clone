import React from "react";
import SingleHotelComponent from "../../components/singleHotelComponent/singleHotelComponent";

const SingleHotelPage = () => {
  return (
    <div>
      <SingleHotelComponent />
    </div>
  );
};

export default SingleHotelPage;
