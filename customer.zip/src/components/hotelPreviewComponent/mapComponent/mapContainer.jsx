import GoogleMapReact from "google-map-react";
import MarkerComponent from "./markerComponent";

const AnyReactComponent = ({ text, data }) => (
  <div style={{ height: "10px" }}>
    <MarkerComponent text={text} data={data} />
  </div>
);

const API_KEY = "AIzaSyCxZlpDt6yJWXjHqVQYa__pHusnmbY7YSo";

const ContactComponent = ({ state }) => {
  return (
    <>
      <GoogleMapReact
        bootstrapURLKeys={{
          key: API_KEY,
        }}
        yesIWantToUseGoogleMapApiInternals={true}
        defaultZoom={10}
        defaultCenter={{
          lat: +state[1]["hotel-coordinates"].latitude,
          lng: +state[1]["hotel-coordinates"].longitude,
        }}
      >
        <AnyReactComponent
          lat={+state[1]["hotel-coordinates"].latitude}
          lng={+state[1]["hotel-coordinates"].longitude}
          text={`${+state[1]["min-booking-price"]}`}
          data={state[1]}
        />
      </GoogleMapReact>
    </>
  );
};

export default ContactComponent;
