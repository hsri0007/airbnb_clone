import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { useParams } from "react-router-dom";
import { fetchHotels } from "../../apiCalls/apiCalls";
import CardComponent from "../../customComponents/cardComponent/cardComponent";
import MapComponent from "./mapComponent/mapContainer";

const HotelPreviewComponent = () => {
  const [state, setState] = React.useState([]);

  const params = useParams();
  React.useEffect(() => {
    fetchHotels(params.rid).then((res) => setState(res.data));
  }, [params]);
  return (
    <div style={{ paddingTop: "10vh", background: "black", minHeight: "90vh" }}>
      <Container>
        <Row>
          <Col>
            <Row>
              {state.map((res, i) => {
                return (
                  <Col className="mb-5" key={i}>
                    <CardComponent data={res} />
                  </Col>
                );
              })}
            </Row>
          </Col>
          <Col>{state.length > 0 && <MapComponent state={state} />}</Col>
        </Row>
      </Container>
    </div>
  );
};

export default HotelPreviewComponent;
